from pygame import *
from random import randint
import json
window = display.set_mode((700,500))
background = transform.scale(image.load('background.jpg'),(700,500))
display.set_caption('Ping Pong')
clock = time.Clock()
FPS = 120
mixer.init()
mixer.music.load('Music.mp3')
mixer.music.play()
wins = mixer.Sound('Win.wav')
gwin = mixer.Sound('GrandWin.mp3')
p1s = mixer.Sound('Ping.wav')
p2s = mixer.Sound('Pong.wav')
wsa = mixer.Sound('BonkA.mp3')
wsb = mixer.Sound('BonkB.mp3')
ls = mixer.Sound('Lose.mp3')
ps = mixer.Sound('Pause.wav')
rs = mixer.Sound('Resume.wav')
res = mixer.Sound('Reset.wav')
err = mixer.Sound('Error.mp3')
loads = mixer.Sound('Loaded.mp3')
savs = mixer.Sound('Saved.mp3')
ballspeedx = 1.5
ballspeedy = 1.5
savebsx = 0
savebsy = 0
speedup = 0
bally = 235
score1 = 0
score2 = 0
finish = False
pause = False
game = True
savedata = None
font.init()
font0 = font.SysFont('Segoe UI',70)
font1 = font.SysFont('Segoe UI',36)
wintext = ''
win = font0.render(wintext, True, (255,215,0))

class gsprite(sprite.Sprite):
    def __init__(self,plrimg, plrx, plry, plrspd,plrw,plrh):
        super().__init__()
        self.img = transform.scale(image.load(plrimg),(plrw,plrh))
        self.spd = plrspd
        self.rect = self.img.get_rect()
        self.rect.x = plrx
        self.rect.y = plry
    def reset(self):
        window.blit(self.img, (self.rect.x, self.rect.y))
class plr(gsprite):
    def __init__(self,plrimg, plrx, plry, plrspd,plrw,plrh,plrn):
        super().__init__(plrimg, plrx, plry, plrspd,plrw,plrh)
        self.number = plrn
    def update(self):
        bally = self.rect.y
        kp = key.get_pressed()
        if not pause:
            if self.number == 2:
                if kp[K_UP] and self.rect.y > 0:
                    self.rect.y -= self.spd
                if kp[K_DOWN] and self.rect.y < 380:
                    self.rect.y += self.spd
            else:
                if kp[K_w] and self.rect.y > 0:
                    self.rect.y -= self.spd
                if kp[K_s] and self.rect.y < 380:
                    self.rect.y += self.spd
sprite1 = plr('square.png',0,0,5,20,120,1)
sprite2 = plr('square.png',680,0,5,20,120,2)
sprite3 = gsprite('ball.png',235,235,10,50,50)
while game:
    if not finish:
        clock.tick(FPS)
        window.blit(background,(0,0))
        sprite1.update()
        sprite2.update()
        sprite1.reset()
        sprite2.reset()
        sprite3.reset()
        sprite3.rect.x += ballspeedx
        sprite3.rect.y += ballspeedy
        if sprite.collide_rect(sprite1,sprite3):
            p1s.play()
            if ballspeedx < 0:
                ballspeedx *= -1
            #ballspeedy *= -1
            speedup = randint(1,40)
            speedup /= 20
            if ballspeedx < 0:
                ballspeedx = (1.5 + speedup) * -1
            else:
                ballspeedx = 1.5 + speedup
            if ballspeedy < 0:
                ballspeedy = (1.5 + speedup) * -1
            else:
                ballspeedy = 1.5 + speedup
        if sprite.collide_rect(sprite2,sprite3):
            p2s.play()
            if ballspeedx > 0:
                ballspeedx *= -1
            #ballspeedy *= -1
            speedup = randint(1,40)
            speedup /= 20
            if ballspeedx < 0:
                ballspeedx = (1.5 + speedup) * -1
            else:
                ballspeedx = 1.5 + speedup
            if ballspeedy < 0:
                ballspeedy = (1.5 + speedup) * -1
            else:
                ballspeedy = 1.5 + speedup
        if sprite3.rect.y <= 0 or sprite3.rect.y >= 450:
            wsb.play()
            wsa.play()
            if sprite3.rect.y >= 450 and ballspeedy > 0:
                ballspeedy *= -1
            elif sprite3.rect.y <= 0 and ballspeedy < 0:
                ballspeedy *= -1
            if sprite3.rect.y <= -15 or sprite3.rect.y >= 465:
                ls.play()
                sprite3.rect.y = 235
        if sprite3.rect.x <= -75:
            score2 += 1
            if str(score2)[-1:] == '5' or str(score2)[-1:] == '0':
                wintext = 'Игрок 2 победил '+str(score2)+' раз!'
                gwin.play()
            else:
                wintext = 'Игрок 2 победил!'
            wins.play()
            win = font0.render(wintext, True, (255,215,0))
            window.blit(win,(100,200))
            finish = True
        elif sprite3.rect.x >= 730:
            score1 += 1
            if str(score1)[-1:] == '5' or str(score1)[-1:] == '0':
                wintext = 'Игрок 1 победил '+str(score1)+' раз!'
                gwin.play()
            else:
                wintext = 'Игрок 1 победил!'
            wins.play()
            win = font0.render(wintext, True, (255,215,0))
            window.blit(win,(100,200))
            finish = True
        kp = key.get_pressed()
        tcght = font1.render('Счёт: ' + str(score1),1,(255,255,255))
        window.blit(tcght,(10,20))
        tcght = font1.render('Счёт: ' + str(score2),1,(255,255,255))
        window.blit(tcght,(510,20))
        tcght = font1.render('Escape - пауза',1,(255,255,255))
        window.blit(tcght,(220,20))
        if kp[K_ESCAPE]:
            if ballspeedx != 0 and ballspeedy != 0:
                ps.play()
                pause = True
                savebsx = ballspeedx
                savebsy = ballspeedy
                ballspeedx = 0
                ballspeedy = 0
                time.delay(300)
            else:
                rs.play()
                pause = False
                ballspeedx = savebsx
                ballspeedy = savebsy
                time.delay(300)
        if pause:
            wintext = 'Пауза'
            win = font0.render(wintext, True, (255,215,0))
            window.blit(win,(200,200))
            if score1 != 0 or score2 != 0:
                tcght = font1.render('Пробел - обнулить',1,(255,255,255))
                window.blit(tcght,(220,460))
                tcght = font1.render('Enter - сохранить',1,(255,255,255))
                window.blit(tcght,(220,440))
                if kp[K_SPACE]:
                    res.play()
                    score1 = 0
                    score2 = 0
                elif kp[K_RETURN]:
                    savedata = {"score":{"score1":score1,"score2":score2}}
                    try:
                        #open("savedata.json", "w", encoding="utf-8")
                        with open ("savedata.json", "w", encoding="utf-8") as file:
                            json.dump(savedata,file)
                            savs.play()
                            tcght = font1.render('Сохранено!',1,(255,255,255))
                            window.blit(tcght,(220,420))
                    except:
                        loads.play()
                        tcght = font1.render('Ошибка.',1,(255,255,255))
                        window.blit(tcght,(220,420))
                    time.delay(300)
            else:
                tcght = font1.render('Enter - загрузить',1,(255,255,255))
                window.blit(tcght,(220,440))
                if kp[K_RETURN]:
                    try:
                        open("savedata.json", "r", encoding="utf-8")
                        with open ("savedata.json", "r", encoding="utf-8") as file:
                            savedata = file.read()
                            loads.play()
                            score1 = int(savedata[savedata.find('score1')+8:savedata.find('score2')-3])
                            score2 = int(savedata[savedata.find('score2')+8:len(savedata)-2])
                            tcght = font1.render('Загружено!',1,(255,255,255))
                            window.blit(tcght,(220,420))
                    except:
                        tcght = font1.render('Ошибка.',1,(255,255,255))
                        window.blit(tcght,(220,420))
                    time.delay(300)

    else:
        time.delay(3000)
        finish = False
        sprite3.rect.y = 235
        sprite3.rect.x = 235
        ballspeedx = 3
        ballspeedy = 3
        speedup = 0
    for e in event.get():
        if e.type == QUIT:
            game = False
    display.update()